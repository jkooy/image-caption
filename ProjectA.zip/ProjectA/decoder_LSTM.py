import os
import numpy as np 
import torch
from torch import nn
from torch.nn import functional as F 
import torch.utils.data as td
import torch.nn.utils.rnn as tr
import torchvision as tv
import pandas as pd
from PIL import Image
from matplotlib import pyplot as plt

device = 'cuda' if torch.cuda.is_available() else 'cpu' 
print(device)

class decoderLSTM(nn.Module):
    def __init__(self,embedding_size,hidden_size,vocab_size,beam_size = 20,dropout=0.5):   # Add parameters here - maybe add dropout later
        # Parameters:
        #    embedding_size: the initial state of the first LSTM
        #    hidden_size: the dimension of hidden states
        #    vocab_size: the dimension of the vocabulary space
        super(decoderLSTM, self).__init__()
        self.embedding_size = embedding_size
        self.hidden_size = hidden_size
        self.vocab_size = vocab_size
        self.beam_size = beam_size
        self.dropout = dropout
        
        # the embedding layer 
        self.word_embeddings = nn.Embedding(self.vocab_size, self.embedding_size)
        
        # the lstm cell - 
        self.lstm = nn.LSTM(self.embedding_size, self.hidden_size)
        
        # the output of an LSTM cell is the hidden state vector. space.
        # Requirs a mapping from hidden state spce -> vocabulary space
        # Using a fully connected layer to achieve the goal
        self.fc = nn.Linear(self.hidden_size, self.vocab_size)
        
        # activations function
        self.softmax = nn.Softmax(dim=1)
        
        # the dropout layer
        self.dropout = nn.Dropout(p=self.dropout)
        
        
    def forward(self, feature, captions, length):
        # Parameters:
        #    feature: the output of the encoder (CNN)
        #    captions: padded image captions
        #    length: actual length captions
        #    return: the distribution over the vocabulary
        
        #transfer the caption to real numbers
        embedded_caption = self.word_embeddings(captions)
        
        #connect the feature with caption 
        feature_3D = torch.unsqueeze(feature,1) # convert 2D feature to 3D feature by adding one dimension
        Lstm_feedin = torch.cat((feature_3D, embedded_caption),dim=1)
        
        # padding features and caption to be the same size, which can be processed by Pytorch later
        Lstm_feedin = tr.pack_padded_sequence(Lstm_feedin, length, batch_first = True)
        
        #input the Lstm_feedin to lstm (not lstm_cell which is one layer)
        hidden_states, cell = self.lstm(Lstm_feedin)
        
        #hidden_states[0] is all hidden_state
        outputs = self.fc(hidden_states[0])
        
        return outputs
    
  
    #using in the prediction (not in train), to make sure the output caption meaningful 
    def sample(self, feature, cell=None):
        #input the feature for fist layer 
        #return the image caption
        
        sample_ids = []
        
        feature_3D = torch.unsqueeze(feature,1)
        inputs = feature_3D
        
        for i in range(self.beam_size):
            #if i == 0:
            #hidden_state, cell = self.lstm(feature_3D)
            #else:
            hidden_state, cell = self.lstm(inputs, cell)
            
            #convert hidden_state (output is 3D) to 2D (for fc layer input)
            hidden_state_2D = torch.squeeze(hidden_state,1)
            vocab = self.fc(hidden_state_2D)
            
            #not sure about choosing the index or word to embedding
            #choosing the max_value index as output
            
            predicted = torch.max(vocab, 1)[1]
            #predicted = torch.argmax(vocab, 1)
            
            sample_ids.append(predicted)
            
            inputs = self.word_embeddings(predicted)
            inputs = torch.unsqueeze(inputs,1)
            
        sample_ids = torch.stack(sample_ids,1)    
        return sample_ids.squeeze()
    
   