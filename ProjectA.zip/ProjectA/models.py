import torch
from torch import nn
from torch.nn import Sequential
from torchvision import models
from torch.autograd import Variable
from torch.nn.utils.rnn import pack_padded_sequence

class CNN(nn.Module):
    def __init__(self, output_dim=1000):
        super(CNN, self).__init__()
        pretrained_model = models.resnet34(pretrained=True)
        # use pretrained resnet34 nework
        self.resnet = Sequential(*list(pretrained_model.children())[:-1])
        self.linear = nn.Linear(pretrained_model.fc.in_features, output_dim)
        self.init_weights()
        # batch normaliztion
        self.batchnorm = nn.BatchNorm1d(output_dim, momentum=0.01)
    
    
    def init_weights(self):
        # weight initialization using normal distribution
        self.linear.weight.data.normal_(0,0.02)
        # bia initialization with all zero
        self.linear.bias.data.fill_(0)
    
    def forward(self, x):
        x = self.resnet(x)
        # flatten the features
        x = x.view(x.size(0), -1)
        #add a linear layer in the last layer to replace the original one in the resnet34 network
        x = self.linear(x)
        return x

