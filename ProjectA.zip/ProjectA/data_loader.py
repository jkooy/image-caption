import torch
import torchvision.transforms as transforms
import torch.utils.data as data
import os
import numpy as np
import nltk
from PIL import Image
from pycocotools.coco import COCO

class CocoDataset(data.Dataset):
    def __init__(self, path, json, vocab=None, transform=None):

        self.path = path
        self.coco = COCO(json) # object of Coco Helper Class
        self.ids = list(self.coco.anns.keys()) # unique identifiers for annontations
        self.vocab = vocab
        self.transform = transform

    def __getitem__(self,index):
        
        coco = self.coco
        vocab = self.vocab
        annotation_id = self.ids[index]
        caption = coco.anns[annotation_id]['caption']
        image_id = coco.anns[annotation_id]['image_id']
        path = coco.loadImgs(image_id)[0]['file_name']

        image = Image.open(os.path.join(self.path, path))
        image = image.convert('RGB')

        if self.transform != None:
            image = self.transform(image)

        caption_str = str(caption).lower()
        tokens = nltk.tokenize.word_tokenize(caption_str)
        caption = torch.Tensor([vocab(vocab.start_token())] +
                               [vocab(token) for token in tokens] +
                               [vocab(vocab.end_token())])

        return image, caption

    def __len__(self):
        return len(self.ids)

def collate_fn(data):

    data.sort(key=lambda x: len(x[1]), reverse=True)
    images, captions = zip(*data)
    images = torch.stack(images, 0)
    caption_lengths = [len(caption) for caption in captions]
    padded_captions = torch.zeros(len(captions), max(caption_lengths)).long()
    for ix, caption in enumerate(captions):
        end = caption_lengths[ix]
        padded_captions[ix, :end] = caption[:end]
    return images, padded_captions, caption_lengths

def get_coco_data_loader(path, json, vocab, transform=None,
        batch_size=32, shuffle=True, num_workers=1):

    coco = CocoDataset(path=path,
                       json=json,
                       vocab=vocab,
                       transform=transform)

    data_loader = torch.utils.data.DataLoader(dataset=coco,
                                              batch_size=batch_size,
                                              shuffle=shuffle,
                                              num_workers=num_workers,
                                              collate_fn=collate_fn)

    return data_loader
